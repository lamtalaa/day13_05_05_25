# Supercenter App

This is an iOS application that displays a list of products. But it's buggy and doesn't work right now. Your job is to fix it.

## Mock Server

There is an accompanying mock server in the folder "mock-server". See the [ReadMe](mock-server/ReadMe.md) for instructions on setting up and running it.

## Ways to enhance it

1. Add pull to refresh.
2. Add a try-again button to the "error" cell.
3. Add a detail view for the products.
